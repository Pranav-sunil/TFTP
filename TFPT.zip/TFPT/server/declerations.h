#ifndef SERVER_H
#define SERVER_H

#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <stdio_ext.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>

#define IP_ADDRESS			 "127.0.0.1"
#define	PORT_NO				 5028

#define	SERVER_SIZE			 10

#define FAILURE				-1
#define SUCCESS			 	 1 

#define  PUT			 	 3
#define  GET			 	 4

#define NORMAL_MODE			'N'
#define OCTET_MODE			'O'
#define NET_ASCII			'A'

#define SERVER_READY		 0
#define END					'E'
#define DISCONNECT			'D'
#define CLIENT_READY		'C'


#define RED                 "\033[31m"
#define CYAN                "\033[36m"
#define GREEN               "\033[32m"
#define WHITE               "\033[97m"

#define ORANGE				"\033[38;5;208m"

/* Structure used for data transfer */
struct Data_Packets
{
	char buffer[512];
	int byte;
	int packet_no;
	char mode;
	char oper;
	char errn;
};

/* Function to read option from user and perfrom operation */
void server_operations();

/* Function to establish connection with the server */
int establish_server( int *sock_fd);

/* Function to receive a file to the server */
int receive_file( struct Data_Packets *packet, int sock_fd );

/* Function to send the file requested by the client */
int send_file( struct Data_Packets *packet, int sock_fd );

#endif 
