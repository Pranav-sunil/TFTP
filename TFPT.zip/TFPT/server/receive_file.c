#include "declerations.h"

//Function to receive the file sent by the server
int receive_file( struct Data_Packets *packet, int sock_fd )
{
	//Char array to store the file name received from the client
	char file_name[30];

	//Variable to store the file FD
	int fd;

	//Variable to keep track of amount of data written to file
	int wr_byte;

	//Variable to count the number of packets
	int count = 0;

	int i; //Variable to run the loop

	//Receive the file name from the user
	recv( sock_fd, (void *)packet, sizeof( *packet), 0 );

	//Retriving the file name from the packet
	strcpy( file_name, packet->buffer );

	//Opening the file
	fd = open( file_name, O_WRONLY | O_TRUNC );

	//Checking if the file was opened
	if( fd < 0 )
	{
		//If file does not exist, creating the file
		printf( CYAN "INFO: ");
		printf( WHITE "File does not exist. Creating file\n");

		fd = open( file_name, O_WRONLY | O_CREAT, 0644 );

		if( fd < 0 )
		{
			printf( RED "ERROR: ");
			printf( WHITE "Unable to create file\n");

			//Sending error signal to the client
			packet->errn = FAILURE;
			send( sock_fd, packet, sizeof( *packet), 0 );

			return FAILURE;
		}
	}
	else
	{
		printf( CYAN "INFO: ");
		printf( WHITE "File does exists. Opening and clearing the contents of the file\n");
	}

	//After file has been created, send acknowledgement back to client to start sending file data
	packet->errn = SERVER_READY;
	send( sock_fd, packet, sizeof( *packet), 0 );

	printf( CYAN "INFO: ");
	printf( WHITE "Server is ready to accept data from client\n");

	//Using a loop to receive 
	do
	{
		//Receiving file data from user
		recv( sock_fd, (void *)packet, sizeof( *packet), 0 );

		//Writing to the file
		if( packet->mode != NET_ASCII )
		{
			wr_byte = write( fd, packet->buffer, packet->byte );
		}
		else
		{
			//Convertion for .Net ASCII mode
			wr_byte = 0;

			for( i = 0 ; i < packet->byte ; i++ )
			{
				if( packet->buffer[i] != '\n' )
				{
					wr_byte += write( fd, &packet->buffer[i], 1 );
				}
				else
				{
					write( fd, "\r", 1);
					wr_byte += write( fd, &packet->buffer[i], 1 );
				}
			}
		}

		//Verifying if write operation was successful
		if( wr_byte != packet->byte )
		{
			printf( RED "ERROR: ");
			printf( WHITE "Write size mismatch occured\n");

			packet->errn = FAILURE;
			send( sock_fd, packet, sizeof( *packet), 0 );
			return FAILURE;
		}

		if( packet->errn != END )
		{
			//If write operation was successful, send back acknowledgement
			packet->errn = SERVER_READY;
		}
		send( sock_fd, packet, sizeof( *packet), 0 );
		count++;

	}while( packet->errn != END );

	printf( CYAN "INFO: ");
	printf( WHITE "Server has received data from client\n");

	//Close the file
	if( close(fd) < 0 )
	{
		packet->errn = FAILURE;
		send( sock_fd, packet, sizeof( *packet), 0 );
		return FAILURE;
	}

	//Sending acknowledgement back to client
	packet->errn = SUCCESS;
	send( sock_fd, packet, sizeof( *packet), 0 );

	printf( CYAN "INFO: ");
	printf( WHITE "Number of packets received : %d\n", count);

	return SUCCESS;
}
