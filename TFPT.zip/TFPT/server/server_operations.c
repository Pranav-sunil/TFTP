#include "declerations.h"

//Function to perfrom the server operation
void server_operations()
{
	//Declaring a variable for sending and recieveing packet data
	struct Data_Packets packet;

	int server_sock; //Variable to store the server socket fd
	int client_sock; //Variable to store the client socket fd
	int operation = -1; //Variable to store the operation requested by client

	//Creating the server with the TCP sokcet
	if( establish_server( &server_sock ) == FAILURE )
	{
		printf( RED "ERROR: ");
		printf( WHITE "Unable to create server socket\n");
		_exit(-1);
	}

	printf("____________ TFTP SERVER ____________ \n");
	printf("SERVER IS ");
	printf( GREEN "ACTIVE\n");
	printf( WHITE "IP ADDRESS : %s\n", IP_ADDRESS );
	printf("PORT NUMBER : %d\n\n", PORT_NO );

	/* Listening for client connection requests */
	listen( server_sock, SERVER_SIZE );

	//Running a loop to accept multiple clients
	while(1)
	{
		/* Accepting the client */
		client_sock = accept( server_sock, NULL, NULL );

		//Creating a child process for accepting client request
		int pid = fork();

		if( pid == 0 )
		{
			//Server operations
			printf( CYAN "INFO: ");
			printf( WHITE "Connected with client\n");
			//Receiving data from client
			while( 1 )
			{
				recv( client_sock, (void *)&packet, sizeof( packet ), 0 );

				if( packet.errn == 1 )
				{
					printf( CYAN "INFO: ");
					printf( WHITE "Server Acknowledges client request\n");
					packet.errn = SERVER_READY;
					operation = packet.oper;

					//Sending acknowledgement back to the client
					send( client_sock, &packet, sizeof( packet ), 0 );

					//Checking the operation requested by client
					if( operation == PUT )
					{
						/* Client sending file to the server */
						printf( CYAN "INFO: ");
						printf( WHITE "Client has requested to send file\n");
						if( receive_file( &packet, client_sock ) == SUCCESS )
						{
							printf( CYAN "INFO: ");
							printf( WHITE "Sucessfully received the file\n");
						}
						else
						{
							printf( RED "ERROR: ");
							printf( WHITE "File not received\n");
						}
					}
					else if( operation == GET )
					{
						/* Client requesting file from the srever */
						printf( CYAN "INFO: ");
						printf( WHITE "Client has requested for file from server\n");
						if( send_file( &packet, client_sock ) == SUCCESS )
						{
							printf( CYAN "INFO: ");
							printf( WHITE "Sucessfully sent the file to the client\n");
						}
						else
						{
							printf( RED "ERROR: ");
							printf( WHITE "File not sent\n");
						}
					}
					else if( operation == DISCONNECT )
					{
						printf( CYAN "INFO: ");
						printf( WHITE "Client has disconnected\n");
						break;
					}
				}
			}

			/* After the client disconnects, closing the client socket and terminating the child */
			close( client_sock );
			_exit(0);	
		}
	}
}
