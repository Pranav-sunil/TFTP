#include "declerations.h"

/* Function to send the file requested by client */
int send_file( struct Data_Packets *packet, int sock_fd )
{
	//Array to store the file name
	char file_name[30];

	//Variable to store the file fd
	int fd;

	//Variable to store the amount of data read from the file
	int rd_byte;

	//Variable to count the number of packets of data exchanged
	int count = 0;

	//Variable to set the packet size based on client mode
	int pack_size;

	//Receiving the file name from the client
	recv( sock_fd, packet, sizeof( *packet), 0 );

	strcpy( file_name, packet->buffer );

	//Validating if the file exists
	fd = open( file_name, O_RDONLY );

	if( fd < 0 )
	{
		printf( RED "ERROR: ");
		printf( WHITE "File requested by client does not exist on server\n");

		//Send back information to client
		packet->errn = FAILURE;
		send( sock_fd, packet, sizeof( *packet), 0 );

		return FAILURE;
	}

	//Checking the mode of operation
	if( packet->mode != OCTET_MODE )
	{
		pack_size = 512;
	}
	else if( packet->mode == OCTET_MODE )
	{
		pack_size = 1;
	}

	//If file exists send back acknowledgement to client
	packet->errn = SUCCESS;
	send( sock_fd, packet, sizeof( *packet), 0 );

	/*Checking if the file has been created at client side and the client is ready to receive data*/
	recv( sock_fd, packet, sizeof( *packet), 0 );

	if( packet->errn == FAILURE )
	{
		printf( RED "ERROR: ");
		printf( WHITE "Client is not able to create file\n");
		return FAILURE;
	}

	//If the client is ready to accept data, start sending data
	do
	{
		//Read from the file
		rd_byte = read( fd, packet->buffer, pack_size );

		packet->byte = rd_byte;
		packet->errn = 1;

		//Checking if the complete data from the file has been read
		if( rd_byte == 0 )
		{
			//Setting end of operation flag
			packet->errn = END;
		}

		//Sending the packet to the client
		send( sock_fd, packet, sizeof( *packet ), 0 );

		//Receive acknowledgement from client if write was succesful
		recv( sock_fd, packet, sizeof( *packet), 0 );
		count++;

		if( packet->errn == FAILURE )
		{
			//If write operation at client side was not successful, terminate operation
			close( fd );
			return FAILURE;
		}

	}while( rd_byte != 0 );

	//Receive client acknowledgement
	recv( sock_fd, packet, sizeof( *packet), 0 );

	//Close the file 
	close( fd );

	if( packet->errn != SUCCESS )
	{
		return FAILURE;
	}

	printf( CYAN "INFO: ");
	printf( WHITE "Number of packets sent : %d\n", count );

	return SUCCESS;
}
