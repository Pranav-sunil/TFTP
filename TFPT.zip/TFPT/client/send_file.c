#include "declerations.h"

extern int pack_size;

//Function to send a file to the server
int send_file( struct Data_Packets *packet, int sock_fd )
{
	//Array to store the file name
	char file_name[30];

	//Variable to keep tarck of amount of data fetched from the file
	int rd_size;

	//Variable to store the fd of the file to be sent
	int file_fd;

	__fpurge(stdin);
	//Reading the name of the file to be sent to the user
	printf("Enter name of file to be sent to the server : ");
	scanf("%[^\n]", file_name );

	//Opening and validating if the file exists
	file_fd = open( file_name, O_RDONLY );

	if( file_fd < 0 )
	{
		printf( RED "ERROR: ");
		printf( WHITE "File %s does not exist\n", file_name);
		return FAILURE;
	}

	//Sending indication to server that file will be sent to it
	packet->oper = PUT;
   	packet->errn = 1;

	send( sock_fd, packet, sizeof( *packet ), 0 );

	printf( CYAN "INFO: ");
	printf( WHITE "Indication sent to server. Waiting for server acknowledgement\n");

	//Receiving the acknowledgment from the server
	recv( sock_fd, (void *)packet, sizeof( *packet), 0 );
		
	//Checking if the server has acknowledged the request
	if( packet->errn == SERVER_READY )
	{
		printf( CYAN "INFO: ");
		printf( WHITE "Server Acknowledges request\n");
	}
	else
	{
		printf( CYAN "INFO: ");
		printf( WHITE "Server has not acknowledged the request\n");
		return FAILURE;
	}
		
	__fpurge(stdin);

	strcpy( packet->buffer, file_name );
   	packet->errn = 1;

	//Sending the file name to the server
	send( sock_fd, packet, sizeof( *packet ), 0 );

	//Receive acknowledgement from server to start sending file data
	recv( sock_fd, (void *)packet, sizeof( *packet), 0 );

	if( packet->errn == FAILURE )
	{
		printf( RED "ERROR: ");
		printf( WHITE "Server is unable to receive file\n");
		return FAILURE;
	}

	//Using a loop to send the file data
	do
	{
		//Reading from file 
		rd_size = read( file_fd, packet->buffer, pack_size );
		
		//Setting the packet size
		packet->byte = rd_size;
		packet->errn = 1;

		//Checking if the complete data from file has been read
		if( rd_size == 0 )
		{
			//Setting end of operation flag
			packet->errn = END;
		}

		//Sending the packet to the client
		send( sock_fd, packet, sizeof( *packet ), 0 );

		//Receive acknowledgement from server if write operation was successful
		recv( sock_fd, (void *)packet, sizeof( *packet), 0 );

		if( packet->errn == FAILURE )
		{
			//If write op was not successful, terminate operation
			close( file_fd );
			return FAILURE;
		}
	
	}while( rd_size != 0 );

	//Receive server acknowledgement 
	recv( sock_fd, (void *)packet, sizeof( *packet), 0 );

	//Close the file
	close( file_fd );

	if( packet->errn != SUCCESS )
	{
		return FAILURE;
	}

	return SUCCESS;
}
