#include "declerations.h"

int pack_size; //Variable to change the amount fo data read from the file based on the mode

//Function to read the option from the user and perfrom the operation
void client_operations()
{
	int opt, mode_option; //Variable to read opion from the user
	int connect_flag = 0; //Flag to prevent the user from acccessing other options without connecting

	char ip_address[IP_ADDR_LEN]; //Array to store the IP address read from user
	int port_no; //Variable to store the port number
	int sock_fd; //Variable to store the socket id

	//Structure Variable to send and recieve data
	struct Data_Packets packet;

	packet.mode = NORMAL_MODE; //Setting the mode as Normal by default
	pack_size = 512; //Setting 512 bytes in normal mode
	packet.errn = 8;
	packet.oper = 8;

	do
	{
		print_client_menu();
		scanf("%d", &opt );

		switch(opt)
		{
			case 1:
				//To connect
				if( connect_flag == 1 )
				{
					printf( CYAN "INFO: ");
					printf( WHITE "Client already connected with server");
					printf(" IP : %s\t", ip_address );
					printf("PORT NO : %d\n", port_no );
					break;
				}
read_ip:
				__fpurge(stdin);

				printf("Enter the IP Address : ");
				scanf("%[^\n]", ip_address );
				
				//Validating the IP address entered by the user
				if( validate_ip_address( ip_address ) == SUCCESS )
				{	
read_port:
					printf("Enter the port number : ");
					scanf("%d", &port_no );
					
					//Validating the port number entered by the user
					if( port_no < 1024 || port_no > 49151 )
					{
						printf( RED "ERROR: "); 
						printf( WHITE "Invalid Port Number\n");
						printf("Valid Port number range : 1024 - 49151\n");
						goto read_port;
					}
					else
					{
						//Connecting to the server
						if( connect_to_server( ip_address, port_no, &sock_fd) == SUCCESS )
						{
							printf( CYAN "INFO:");
							printf( WHITE " Sucessfully connected to server\n");
							connect_flag = 1;
						}
						else
						{
							printf( RED "ERROR: "); 
							printf( WHITE "Unable to Connect to server\n");
						}
					}	
				}
				else
				{
					printf( RED "ERROR: "); 
					printf( WHITE "Invalid IP Address\n");
					goto read_ip;
				}
				break;
			case 2:
				//To send a file to the server
				
				if( connect_flag == 0 )
				{
					printf( RED "ERROR: "); 
					printf( WHITE "Client has not connected with the server\n");
					break;
				}
				else
				{
					if( send_file( &packet, sock_fd ) == FAILURE )
					{
						printf( RED "ERROR: "); 
						printf( WHITE "Put operation failed\n");
					}
					else
					{
						printf( CYAN "INFO: ");
						printf( WHITE "File has been sent to the server\n");
					}
				}

				break;
			case 3:
				//To get a file from the server
				
				if( connect_flag == 0 )
				{
					printf( RED "ERROR: "); 
					printf( WHITE "Client has not connected with the server\n");
					break;
				}
				else
				{
					if( receive_file( &packet, sock_fd )  == SUCCESS )
					{
						printf( CYAN "INFO: ");
						printf( WHITE "File has been received from the server\n");
					}
					else 
					{
						printf( RED "ERROR: "); 
						printf( WHITE "Get operation failed\n");
					}
				}

				break;
			case 4:
				//To change the mode for pack_size
				printf("Select read mode :\n1. Normal Mode\n2. Octet Mode\n3. NET ASCII Mode\nEnter Option : ");
				scanf("%d", &mode_option );
				switch( mode_option )
				{
					case 1:
						packet.mode = NORMAL_MODE;
						pack_size = 512;
						break;
					case 2:
						packet.mode = OCTET_MODE;
						pack_size = 1;
						break;
					case 3:
						packet.mode = NET_ASCII;
						pack_size = 512;
						break;
					default:
						printf( RED "ERROR: ");
						printf( WHITE "Invalid Option\n");
						break;
				}	
				break;
			case 5:
				//To exit

				//Send indication to server that client is closing the connection
				packet.oper = DISCONNECT;
				send( sock_fd, &packet, sizeof(packet), 0 );
			
				close( sock_fd ); //Closing the TCP Socket
				break;
			default:
				printf( RED "ERROR: "); 
				printf( WHITE "Inavlid choice\n");
				break;
		}
		
		//Reset the packet error flag after each operation 
		packet.errn = 1;

	}while( opt != 5 );
}


//Function to print the client options
void print_client_menu()
{
	printf("\n######## TFTP CLIENT ########\n");
	printf("1. Connect\n2. Put\n3. Get\n4. Mode\n5. Exit\n");
	printf("Enter your choice : ");
}
