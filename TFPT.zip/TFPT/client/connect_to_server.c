#include "declerations.h"

/* Function to establish connection with the server 
   based on user input							*/
int connect_to_server( char *ip, int port, int *sock_fd )
{
	//Creating the TCP client socket
	if( (*sock_fd = socket( AF_INET, SOCK_STREAM, 0 ) ) < 0 )
	{
		printf( RED "ERROR: ");
		printf( WHITE "Unable to create the socket\n");
		return FAILURE;
	}

	//Declaring structure to store the server address and port number
	struct sockaddr_in server_address;

	//Loading server data to the structure array
	server_address.sin_family = AF_INET; //Storing the socket type as TCP
	server_address.sin_port = htons( port ); //Storing Port number
	server_address.sin_addr.s_addr = inet_addr( ip ); //Storing IP Address

	//Connecting to the server
	if( connect( *sock_fd, (struct sockaddr *)&server_address, sizeof( server_address ) ) != 0 )
	{
		printf( RED "ERROR: ");
		printf( WHITE "Unable to establish connection with Server\n");
		return FAILURE;
	}

	return SUCCESS;
}
