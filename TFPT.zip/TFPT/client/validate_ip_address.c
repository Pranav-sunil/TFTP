#include "declerations.h"

/* Function to validate the IP address read from the user */
int validate_ip_address( char *ip )
{
//	printf("INFO: Validating the IP Adrress\n");
	int i = 0, count = 0, delimiter = 0;

	int octet = 0;

	//Running a loop to chck the characters of the string
	while( ip[i] )
	{
		if( ip[i] >= '0' && ip[i] <= '9' )
		{
			//Obtaining the octet value
			octet = (octet*10) + (ip[i]-48);

			count++;

			//Checking if there are more than 3 characters 
			if( count == 4 )
			{
				return FAILURE;
			}
		}
		else if( ip[i] == '.' )
		{
			delimiter++;

			//Checking if there are more than 3 dots
			if( delimiter == 4 )
			{
				return FAILURE;
			}
			
			//Validating the octet value
			if( octet > 255 )
			{
				return FAILURE;
			}

			count = 0;
			octet = 0;
		}
		else
		{
			return FAILURE;
		}
		i++;
	}

	//Checking if the number of delimiters was less than 3
	if( delimiter < 3 )
	{
		return FAILURE;
	}

	return SUCCESS;
}
