#include "declerations.h"

extern int pack_size;

//Function to send a file to the server
int receive_file( struct Data_Packets *packet, int sock_fd )
{
	//Array to store the file name
	char file_name[30];

	//Variable to store the file descriptor
	int file_fd;

	//Variable to keep track of the amount of data written to the file
	int wr_count;

	int i; //Variable for running loop

	//Sending indication to server that file will be fetched by client
	packet->oper = GET;
	packet->errn = 1;

	send( sock_fd, packet, sizeof( *packet ), 0 );

	printf( CYAN "INFO: ");
	printf( WHITE "Indication sent to server. Waiting for server acknowledgement\n");

	//Receiving acknowledgement from server
	recv( sock_fd, (void *)packet, sizeof( *packet), 0 );

	//Checking if server has acknowledged the request
	if( packet->errn == SERVER_READY )
	{
		printf( CYAN "INFO: ");
		printf( WHITE "Server Acknowledges request\n");
	}
	else
	{
		printf( RED "INFO: ");
		printf( WHITE "Server has not acknowledged the request\n");
		return FAILURE;
	}

	__fpurge(stdin);

	//Reading the name of the file to be fetched from the server
	printf("Enter name of the file to be fetched from server : ");
	scanf("%[^\n]", file_name );

	strcpy( packet->buffer, file_name );

	//Sending the name of file back to server
	send( sock_fd, packet, sizeof( *packet ), 0 );

	//Receive acknowledgement from server
	recv( sock_fd, (void *)packet, sizeof( *packet), 0 );

	//Check if file exists at server side
	if( packet->errn == FAILURE )
	{
		printf( RED "ERROR: ");
		printf( WHITE "File does not exist at server side\n");
		return FAILURE;
	}

	//If file exists at server side, create/ open file at client side

	file_fd = open( file_name, O_WRONLY | O_TRUNC );

	//Validate if file has opened
	if( file_fd < 0 )
	{
		//If file does not exist, create new file
		file_fd = open( file_name, O_WRONLY | O_CREAT, 0644 );

		if( file_fd < 0 )
		{
			printf( RED "ERROR: ");
			printf( WHITE "Unable to create the file\n");

			//In case of failure, notify server
			packet->errn = FAILURE;
			send( sock_fd, packet, sizeof( *packet ), 0 );
			return FAILURE;
		}
		else
		{
			printf( CYAN "INFO: ");
			printf( WHITE "File created with name %s\n", file_name );
		}
	}
	else
	{
		printf( CYAN "INFO: ");
		printf( WHITE "File has been opened and previous data has been erased\n" );
	}

	//Notifying the server that the server is ready to accept the data
	packet->errn = CLIENT_READY;
	send( sock_fd, packet, sizeof( *packet ), 0 );

	//Using a loop to receive the data from the server
	do
	{
		//Receive the data from the client
		recv( sock_fd, packet, sizeof( *packet), 0 );

		//Writing the data to the file
		if( packet->mode != NET_ASCII )
		{
			wr_count = write( file_fd, packet->buffer, packet->byte );
		}
		else
		{
			wr_count = 0;

			for( i = 0 ; i < packet->byte ; i++ )
			{
				if( packet->buffer[i] != '\n' )
				{
					wr_count += write( file_fd, &packet->buffer[i], 1 );
				}
				else
				{
					write( file_fd, "\r", 1 );
					wr_count += write( file_fd, &packet->buffer[i], 1 );
				}
			}	
		}

		//Verifying if write operation was succesful
		if( wr_count != packet->byte )
		{
			packet->errn = FAILURE;
			send( sock_fd, packet, sizeof( *packet ), 0 );

			printf( RED "ERROR: ");
			printf( WHITE "Write mismatch occurred\n");
			return FAILURE;
		}

		//Checking for end of operation
		if( packet->errn != END )
		{
			packet->errn = CLIENT_READY;
		}

		//Sending the acknowledgement back to server
		send( sock_fd, packet, sizeof( *packet ), 0 );

	}while( packet->errn != END );

	//Sending final acknowledgement to server to stop the operation
	packet->errn = SUCCESS;
	send( sock_fd, packet, sizeof( *packet ), 0 );

	return SUCCESS;
}
