/* ################################## TFTP - Client ##################################
Name : Pranav S
Name of Project : Implementing TFPT( Trivial File Transfer Protocol )
Description : TFTP is a file transfer protocol that allows the user to send or 
			  receive a file from a remote host/server.
			  This project is the simple implementation of this file transfer protocol

			  This is the client part of the program and allows the user to connect to
			  the host based on the host address and port number input by the user
Type of socket used : TCP 

Github Profile: https://github.com/Pranav-sunil

*/


#include "declerations.h"

int main()
{
	client_operations();

	return 0;
}
